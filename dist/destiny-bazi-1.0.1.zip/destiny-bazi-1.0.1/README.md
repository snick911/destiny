# destiny

子平八字（四柱）排盤程式，使用 Java Swing 打造，內建護眼暗色主題。

輸入西元出生年、月、日、時（下拉選單 0~23 時，並附對應時辰地支；
可選填分鐘）與性別，程式會依「立春」判定
流年、以十二節劃分月柱、以儒略日數推算日柱、並依五鼠遁推算時柱，顯示
年柱、月柱、日柱、時柱的天干地支、五行，以及以日主（日干）為基準推算
的十神（含年干/月干/時干十神，與各柱地支藏干十神）；並依性別與年干
陰陽推算大運（順排／逆排、起運歲數與各期干支、十神、藏干）。

目前版本：**1.0.1**（各版本變更見 [CHANGELOG.md](CHANGELOG.md)）。

## 下載與執行（一般使用者）

到 GitHub 的 [Releases](https://github.com/snick911/destiny/releases) 頁面下載：

- **Windows 免安裝版**（建議，**不需安裝 Java**）：
  `destiny-bazi-<版本>-windows-x64.zip`，解壓縮後雙擊 `DestinyBazi\DestinyBazi.exe`。
  程式未經數位簽章，第一次執行若出現 Windows SmartScreen 警告，請按
  「其他資訊」→「仍要執行」。
- **跨平台版**（需已安裝 Java 17 以上）：`destiny-bazi-<版本>.zip`，解壓縮後
  Windows 雙擊 `run-windows.bat`；macOS / Linux 執行 `./run-mac-linux.sh`，
  或直接 `java -jar destiny-bazi.jar`。

## 執行（直接使用已建置的 JAR）

`dist/destiny-bazi.jar` 是以 `--release 17` 編譯、可獨立執行的 JAR
（位元組碼版本 61＝Java 17；純 JDK，不依賴任何第三方套件），只需
JRE/JDK 17 以上即可直接執行：

```bash
java -jar dist/destiny-bazi.jar
```

## 從原始碼編譯與執行

需要 JDK 17 以上。

```bash
# 編譯（以 Java 17 語言／位元組碼相容性編譯）
javac --release 17 -d out -encoding UTF-8 $(find src/main/java -name "*.java")

# 執行
java -cp out com.destiny.bazi.Main
```

## 測試

```bash
./build.sh
```

`build.sh` 會先編譯並執行 `src/test/java` 的自動測試，**任何一項失敗即停止
打包**。測試不依賴第三方套件，涵蓋：節氣時刻（與 26 筆官方公布時刻比對、
1900~2100 年順序與間隔）、四柱（公開八字、立春交界、子時換日、五虎遁／
五鼠遁）、十神與藏干表、流年流月、大運（順逆、起運、交運日期與各期年份）、
五行質量與十神統計、以傳統口訣查表的獨立實作交叉比對一萬個隨機命盤、
存檔與載入，以及介面冒煙測試（開啟主視窗、切換所有大運／流年／流月、
字體縮放、繪製匯出圖片）與自我檢測。介面測試需要顯示環境；沒有顯示環境時
若有 `xvfb-run` 會自動使用，否則略過。

打包後的程式也可自我檢測：`DestinyBazi.exe --self-test 報告.txt`（或
`java -jar destiny-bazi.jar --self-test 報告.txt`）會開啟主視窗、排一張已知
命盤並寫出報告（作業系統、Java 版本、選用字型、排盤結果），正常時結束碼為
0、報告最後一行為 `result=OK`。GitHub Actions 以此驗證 Windows 免安裝版。

也可只執行測試：

```bash
javac --release 17 -encoding UTF-8 -d out $(find src/main/java -name "*.java")
javac --release 17 -encoding UTF-8 -cp out -d out-test $(find src/test/java -name "*.java")
java -cp out:out-test com.destiny.bazi.tests.AllTests
```

## 打包與發佈新版本

```bash
./build.sh
```

`build.sh` 會在測試通過後重新編譯並產生 `dist/destiny-bazi.jar`（manifest 內含
`Implementation-Version`）與 `dist/destiny-bazi-<版本>.zip`（JAR、啟動檔、
README、CHANGELOG）。發佈新版本的步驟：

1. 修改 `src/main/java/com/destiny/bazi/AppInfo.java` 的 `VERSION`
2. 在 `CHANGELOG.md` 新增該版本的變更紀錄
3. 執行 `./build.sh`，提交 `dist/` 下的新檔案
4. 合併到 `main`：GitHub Actions（`.github/workflows/release.yml`）會自動
   執行測試、建置跨平台 zip 與 Windows 免安裝版（並在 Windows 上執行
   `DestinyBazi.exe --self-test` 驗證），全部成功後建立 `v<版本>` 標籤與 Release 並附上
   兩個 zip；版本號已發佈過則略過，不會覆蓋

Windows 免安裝版由 `jpackage` 在 Windows 上產生（內含只保留 `java.desktop`
模組的精簡 Java 執行環境），因此只在 GitHub Actions 的 Windows 主機上建置；
對 `main` 開的 PR 也會先跑一次建置，確認可以打包。

畫面文字一律使用繁體中文，並會優先選用系統上可用的繁體中文字型
（依序嘗試 Microsoft JhengHei、PingFang TC、Heiti TC、Noto Sans TC 等，
找不到則退回系統無襯線字型）。

## 排盤規則說明

- **年柱**：以「立春」時刻為界，而非西曆 1 月 1 日或農曆春節。
- **月柱**：以十二個「節」（立春、驚蟄、清明…）劃分月支交界，
  月支固定為寅卯辰巳午未申酉戌亥子丑；月干依年干以「五虎遁」推算。
- **日柱**：以儒略日數（Julian Day Number）對 60 取餘推算干支，
  並依「晚子時」慣例，23:00~23:59 出生者日柱順延至次日推算。
- **時柱**：時支依出生時刻對應十二時辰，時干依日干以「五鼠遁」推算。
- **十神**：以日干（日主）為基準，依五行生克與陰陽同異，判定其餘三柱
  天干及四柱地支藏干（本氣／中氣／餘氣）的十神——比肩、劫財、食神、
  傷官、偏財、正財、七殺（偏官）、正官、偏印、正印。
- **月令**：出生時刻在月柱地支中實際「當令」的天干與五行。辰戌丑未
  （四墓庫月）依入節天數分三階段——前 5 天為上個節氣殘留的餘氣當令
  （辰乙木／未丁火／戌辛金／丑癸水，即前一地支本氣），中間 9 天為
  該支所藏墓庫之氣（中氣）當令（辰癸水／未乙木／戌丁火／丑辛金），
  之後（第 15~30 天）才是純粹的本氣（戊／己土）當令；其餘地支不分
  階段，直接以該支本氣為月令。
- **五行質量**：先以原始命盤算出五行基本分——四柱天干權重 1，地支藏干
  依藏干數分配權重（單藏 1；雙藏 2/3、1/3；三藏 2/4、1/4、1/4），總和
  為木火土金水各自的基本分；再以月令五行為「我」，依旺相休囚死為每個
  五行各加一次月令加分——當我者旺（+2）、我生者相（+1.5）、生我者休
  （+1）、剋我者囚（+0.5）、我剋者死（+0）；基本分加上月令加分即為
  五行總分（五者之和固定為 13：基本分總和 8 加上月令加分總和 5）。選定
  大運與流年後，另計算一組「命盤＋大運＋流年」五行質量——以相同方式
  將所選大運柱、流年柱的天干與地支藏干併入基本分（月令加分仍以命盤
  月令為準），五者之和固定為 17（基本分總和 12 加上月令加分總和 5），
  顯示於大運／流年／流月查詢區塊，隨大運或流年切換即時更新。兩組五行
  質量皆以水平長條圖呈現，長條寬度依各五行佔總分的比例繪製，並標示
  數值與百分比；長條圖旁另附十神統計，計算範圍與對應的五行質量一致
  （命盤四柱天干〔日主本身不計〕與地支藏干的十神次數，或再加上所選
  大運柱、流年柱），非零項以強調色標示。
- **大運**：依「陽男陰女順排、陰男陽女逆排」判定方向（陽／陰依年干），
  以出生時刻與最近節氣的距離換算起運歲數（三日折一歲、一日折四個月），
  再從月柱起、依方向逐期推算八期大運（每期十年）的干支、十神與地支藏干。
  出生日期加上起運的歲、月、天即為**交運日期**；第一期大運自交運當年
  起算，其後每期十年，每張大運卡片標示起訖年份與歲數（歲數＝年份－
  出生年，即當年滿幾歲，與流年清單一致）。
- **流年**：選定某一期大運後，可從該期涵蓋的十個西元年份（交運當年起
  連續十年）中選擇特定一年，直接以該年份推算年柱干支、十神與地支藏干。
- **流月**：選定流年後，可從該年正月~十二月中選擇特定一月；月支固定
  順序為寅卯辰巳午未申酉戌亥子丑，月干依該流年年干以「五虎遁」推算，
  同樣附十神與地支藏干。
- 節氣時刻採 VSOP87 地球黃經截斷級數（Meeus《Astronomical Algorithms》
  附錄係數）計算太陽視黃經（含 FK5 修正、章動、光行差），並以 ΔT 換算地球時
  與世界時，搭配牛頓法疊代精確求解每 15° 交角時刻；與香港天文台公布的節氣
  時刻比對誤差約在 1 分鐘以內（舊版低精度公式誤差可達 8 分鐘，交節前後出生者
  可能排錯月柱／年柱）。已與外部命理網站（myfate.herokuapp.com）測試比對，四柱／十神／
  藏干／大運方向與干支序列完全一致，起運天數誤差通常在 1 天以內。
- 所有輸入時間預設視為當地（北京時間 UTC+8）出生時刻。
- 每張柱卡（年柱／月柱／日柱／時柱／各期大運）的天干與地支字元一律
  上緣對齊，不因地支藏干行數（1~3 行）不同而錯位。

## 選單功能

- **檔案 → 儲存結果...**（Ctrl+S）：將目前輸入的出生年月日時分、性別與
  排盤結果存成 `.bazi` 純文字檔（UTF-8）。
- **檔案 → 載入結果...**（Ctrl+O）：讀取 `.bazi` 檔，還原出生年月日時分、
  性別並依目前排盤邏輯重新計算（確保結果與程式版本一致；舊檔案若無
  性別欄位則預設為男）。
- **檔案 → 匯出圖片...**（Ctrl+E）：將排盤輸入、四柱、大運、大運／流年／
  流月查詢、命盤摘要整段內容，依實際完整高度（不受目前視窗大小或捲動
  位置影響）繪製成一張 PNG 圖片並存檔。
- **顯示 → 放大字體 / 縮小字體**（Ctrl+= / Ctrl+-）：等比例調整標題、輸入
  欄位、四柱卡片與大運卡片文字大小；**重設字體大小**（Ctrl+0）恢復預設。
- **說明 → 關於**：顯示版本號與排盤規則簡介。

## 版面配置

畫面由上而下分為五個獨立的卡片區塊，各自加上標題以利區分：
**排盤輸入**（年月日時分、性別、排盤按鈕）→ **四柱**（年柱／月柱／
日柱／時柱）→ **命盤摘要**（含命盤本身的月令與五行質量）→ **大運**
（可橫向捲動的八期大運）→ **大運／流年／流月查詢**（「選擇大運」
「選擇流年」「選擇流月」三個下拉選單，選定後即時顯示該期大運、該年
流年、該月流月的干支、十神、地支藏干，以及「命盤＋大運＋流年」五行
質量）。整體內容置於可垂直捲動的容器中，縮小視窗時不會裁切內容。

選擇大運後，流年下拉選單會自動更新為該期大運涵蓋的十個年份；選擇
流年後，流月下拉選單會自動更新為該年正月~十二月。切換大運、流年或
流月皆會立即重新計算並更新對應卡片，不需再按「排盤」。

## 專案結構

```
.github/workflows/release.yml # 自動打包（含 Windows 免安裝版）與發佈 Release
build.sh                      # 編譯並打包（產生 dist/ 下的 JAR 與 zip）
CHANGELOG.md                  # 版本更新紀錄
packaging/                    # 打包進 zip 的啟動檔（Windows / macOS・Linux）
dist/
├── destiny-bazi.jar          # 已建置好、可直接執行的 JAR（Java 17+）
└── destiny-bazi-1.0.1.zip    # 發佈用壓縮檔（JAR＋啟動檔＋說明文件）
src/test/java/com/destiny/bazi/tests/
├── AllTests.java             # 測試進入點（失敗時結束碼為 1）
├── CalendarTests.java        # 節氣、四柱、口訣表、十神藏干、流年流月
├── DaYunTests.java           # 大運與交運、五行質量、十神統計
├── CrossCheckTests.java      # 獨立實作交叉比對
├── FileIoTests.java          # 存檔與載入
└── UiSmokeTests.java         # 介面冒煙測試
src/main/java/com/destiny/bazi/
├── Main.java                 # 程式進入點
├── SelfTest.java             # 自我檢測（--self-test，驗證打包版本可正常啟動）
├── AppInfo.java              # 程式名稱與版本號（版本號唯一來源）
├── core/
│   ├── GanZhi.java            # 天干地支五行生肖資料表
│   ├── Pillar.java            # 單柱（干支）資料模型
│   ├── SolarTerm.java         # 二十四節氣時刻推算
│   ├── TenGod.java            # 十神判定
│   ├── HiddenStems.java       # 地支藏干表
│   ├── HiddenStemGod.java     # 單一藏干及其十神
│   ├── PillarTenGods.java     # 單柱十神資訊（天干＋地支藏干）
│   ├── MonthOrder.java        # 月令（當令天干、五行、階段、入節天數）
│   ├── FiveElementMass.java   # 五行質量（旺相休囚死加權後的木火土金水總分）
│   ├── Gender.java            # 性別（決定大運順逆排）
│   ├── DaYunPeriod.java       # 單期大運（干支、起訖歲數、十神）
│   ├── DaYunResult.java       # 大運排盤結果
│   ├── LiuNianYear.java       # 單一流年（年份、干支、十神）
│   ├── LiuYueMonth.java       # 單一流月（年份、月份、干支、十神）
│   ├── BaziCalculator.java    # 排盤核心邏輯
│   └── BaziResult.java        # 排盤結果
├── io/
│   ├── BirthInput.java         # 出生年月日時分性別資料
│   └── BaziFileIO.java         # 排盤結果儲存／載入
└── ui/
    ├── DarkTheme.java          # 護眼暗色主題配色（含選單樣式）
    ├── PillarPanel.java        # 單柱顯示卡片（支援緊湊模式與字體縮放）
    ├── FiveElementBarChart.java # 五行質量水平長條圖
    ├── TenGodStatsPanel.java    # 十神統計（各十神出現次數）
    └── BaziFrame.java          # 主視窗（選單列、儲存載入、匯出圖片、字體縮放、大運）
```
